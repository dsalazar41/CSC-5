#include <iostream>
using namespace std;

int main()
{
    /* This problem is from Savitch's textbook and is number 5 of the programming projects.*/
    /* I found mention of the code char in the following chapter, chapter 2, and it seemed like the best idea for this*/
    char letter; 
    
    cout << "Pst. Wanna see something cool?\n";
    cout << "Tell me your favorite letter, and I'll tell you mine!\n";
    cin >> letter;
    cout << letter;
    cout << "? Check this out!\n";
    cout << "                                                               \n";
    cout << "                           ";
    cout << letter;
    cout << letter;
    cout << letter;
    cout << "\n";
    cout << "                          ";
    cout << letter;
    cout << "  ";
    cout << letter;
    cout << "\n";
    cout << "                         ";
    cout << letter;
    cout << "\n";
    cout << "                         ";
    cout << letter;
    cout << "\n";
    cout << "                         ";
    cout << letter;
    cout << "\n";
    cout << "                         ";
    cout << letter;
    cout << "\n";
    cout << "                         ";
    cout << letter;
    cout << "\n";
    cout << "                          ";
    cout << letter;
    cout << "  ";
    cout << letter;
    cout << "\n";
    cout << "                           ";
    cout << letter;
    cout << letter;
    cout << letter;
    cout << "\n";
    cout << "                                                               \n";
    
    return 0;
}
