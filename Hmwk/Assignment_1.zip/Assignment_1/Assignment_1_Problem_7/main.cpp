#include <iostream>
using namespace std;

int main()
{
    /* This is from Savitch's textbook and is problem 2 of the programming projects.*/
    cout << "***************************************************************\n";
    cout << "                                                               \n";
    cout << "           CCC                      SSSS                     !!\n";
    cout << "          C   C                    S    S                    !!\n";
    cout << "         C                        S                          !!\n";
    cout << "        C                          S                         !!\n";
    cout << "        C                           SSSS                     !!\n";
    cout << "        C                               S                    !!\n";
    cout << "         C                               S                   !!\n";
    cout << "          C   C                    S    S                    !!\n";
    cout << "           CCC                      SSSS                       \n";
    cout << "                                                             00\n";
    cout << "                                                               \n";
    cout << "***************************************************************\n";
    cout << "                                                               \n";
    cout << "                                                               \n";
    cout << "Computer Science is Cool Stuff!!!\n";
    
    /* Is there an easier way to do this? */
    return 0;
}